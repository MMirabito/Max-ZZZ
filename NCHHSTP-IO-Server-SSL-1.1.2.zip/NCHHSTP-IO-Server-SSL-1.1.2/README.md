# Server SSL Certificate 
The SSL Certificate checker (serverSSL.ps1) is a PowerShell script used to check an SSL certificate and find out when it expires. The motivation behind this program is discover when SSL certificates are expiring and proactively request and install updated certificates.

* The code will run through a list of servers defined in JSON config file and connecting to the SSL port using the [Net.HttpWebRequest] object.
* TLS 1.2 is supported
* For simplicity The Certificate Validation Callback is always set to true as we are only interested in finding out the expiration date of an SSL cert.
* The original code was adopted from [iamoffthebus.wordpress.com](https://iamoffthebus.wordpress.com/2014/02/04/powershell-to-get-remote-websites-ssl-certificate-expiration/) 

Once the routine has completed it will send out an email enumerating each server that was tested. The email is color coded as follows:

* <span style="color:#009432">**Green**</span> : daysLeft >= 30
* <span style="color:#F79F1F">**Orange**</span> : daysLeft >= 8
* <span style="color:#EA2027">**Red**</span> : daysLeft < 7

EMail rules are as follows:

* Send a **BIMONTHLY STATUS** eMail on the 1st and 15th of each month with a list of certs
* Send a **30 DAY REMINDER** eMail with a list of certs that have reached the 30 day expiration
* Send a **15 DAY REMINDER** eMail with a list of certs that have reached the 15 day expiration
* Send a **DAILY CRITICAL ALERT** eMail every day with a list of  certs that reached the 7 days or less expiration

### Sample eMail:
![Sample eMail](images/email.png)

## Getting Started
The instructions below will get you a copy of the project. Toy can then run it on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

* Using a Git client (i.e. Git cli, VsCode, GitHub Desktop, SourceTree) clone the project into your desktop
  
   ```git clone git@github.com:cdcent/NCHHSTP-DHP-CRF-API.git``` 

* Use and editor such as:
    * [PowerShell Integrated Scripting Environment (ISE)](https://docs.microsoft.com/en-us/powershell/scripting/core-powershell/ise/introducing-the-windows-powershell-ise?view=powershell-6) 
    * Visual Studio Code (VSCode) [Download Link](https://code.visualstudio.com/) and consider installing a PowerShell extension

### Prerequisites
* Some familiarity with PowerShell scripting, but not required
* Microsoft Windows OS
* PowerShell >= 5.0
* It is best to use a code editor that supports PowerShell scripting as indicated above but it's not required

### Configuration
The serverSSL.ps1 program uses a JSON cofing file for configuration **sslConfig.json**. The JSON file includes application information, mail configuration and server list. In most cases the section that will be modified is the **"servers"** section where you will add, update or delete server host information. 
Additionally, you may need to do some adjustments if you are running the code where you cannot access the CDC internal SMTP Gateway. 

    {"version": "1.0.0",
     "build": "25",
     "name": "NCHHSTP SSL-CMS",
     "description": "NCHHSTP SSL Certificate Monitoring Service",
     "debug": true,
     "alwaysSendEmail": true,
     "nchhstpLogo": "assets\\logo-nchhstp-informatics.b64",

     "mailInfo" : {
        "smptServer": "smtpgw.cdc.gov",
        "from": "nchhstp-certs@cdc.gov",
        "to": "user1@cdc.gov;user2@cdc.gov",
        "cc": "user1@cdc.gov;user3@cdc.gov",
        "subject": "NCHHSTP SSL Certificate Monitoring Service"
     },
     "servers": [
        {"skipTest": false, "url": "https://host-1.cdc.gov:443", "organization": "IO", "contactInfo": "user1@cdc.gov;user2@cdc.gov", "type": "Apache 2.4", "environment": "PROD", "description": "My Description"},
        {"skipTest": false, "url": "https://host-2.hce.cdc.gov:8443", "organization": "IO", "contactInfo": "user4@cdc.gov", "type": "??", "environment": "??", "description": "??"},
        {"skipTest": true, "url": "https://????:6443", "organization": "??", "contactInfo": "user1@cdc.gov", "type": "??", "environment": "??", "description": "??"},
     ]}

The **"Servers"** section is an array of JSON objects. Each element represents a host configuration with the following element:

* **skipTest**: Denotes that the item should be skipped from SSL testing
* **url**: The host URL should include the the SSL port
* **organization**: The organization name
* **contactInfo**: The contact information of the person or organization responsible to order and install a new the SSL certificate
* **type**: The Type of server (i.e. Apache, Tomcat, NGNX,  IIS etc. This value is currently user defined) 
* **environment**: The environment type (i.e. PROD, DEV, QA, INT, SBX, etc. This value is currently user defined) 
* **description**: Free form text describing the type of service. For example: ALM Environment Jira/Confluence/Bamboo/Bitbucket (Azure) or Apache Forwarder, etc
  
## Running
There are several ways to run a PowerShell script, the simplest way:

* From the command line navigate to the root folder and enter: 

```Powershell.exe -file serverSSL.ps1``` or simply type ```run``` to leverage the batch file

* Optional arguments:  ```-help``` ```-h``` ```?``` ````-debug``` ```-noip``` ```-sbx```

* From VSCode install the PowerShell extension to debug and run the code

### Below is what the console will show after running the the script:
![Console Image](images/console.png)

## Contributing
Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct, and the process for submitting pull requests to us. 

**NOTE:** You are welcome to fork the repo and/or submit pull request if you would like to share your enhancements.

## Versioning
Version 0.9.0 - Initial release

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://aspv-nifm-alm.cdc.gov/BITBUCKET/projects/PROJECT/REPO). 
            

## Authors
* **Massimo Mirabito** - *Initial work* - <mcm8@cdc.gov>
* **Silver Wang** - *Initial work* - <shw3@cdc.gov>
* **Brian Lee** - *Contributor* - <fya1@cdc.gov>
* **Thom Sukalac** - *Product Owner* - <tks4@cdc.gov>
* **Doung Correll** - *Product Owner* - <wdc0@cdc.gov>


## License
This project is licensed under the Apache License - see the [LICENSE.md](LICENSE.md) file for details

## Acknowledgments
* Initial SSL Certificate check was adopted from: [iamoffthebus.wordpress.com](https://iamoffthebus.wordpress.com/2014/02/04/powershell-to-get-remote-websites-ssl-certificate-expiration/)



