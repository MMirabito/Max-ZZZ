# ************************************************************************************************
#      _       _       __ _ _   _                                                 
#     / \   __| | __ _ \ \ \ \ (~) NCHHSTP - Informatics Office 
#    / _ \ / _` |/ _` | \ \ \ \ #  National Center for HIV, Viral Hepatitis, STD and TB Prevention 
#   / ___ \ (_| | (_| |  ) ) ) )   Centers for Disease Control and Prevention 
#  /_/   \_\__,_|\__, | / / / /    Department of Health and Human Services 
#  ==============|___/=/_/_/_/====================================================================
#
# Powershell script  
#
# Name: serverSSL.ps1
# Version: 0.9.8
# Date: 8/10/2018
# Last Revised: 09/07/2024
# Author(s): Massimo Mirabito (mcm8@cdc.gov)
#            Silver Wang (shw3@cdc.gov)
#
# Purpose: Read a list of URLs and extracts the SSL certificate to read verify it will expire. 
# The programs will send out a email enumerating each server and showing when the certificate
# was issued, will expire and the days remaining. The email is color code as follows:
#   1) daysLeft >= 30 -> Green
#   2) daysLeft >= 8 -> Orange
#   3) daysLeft < 7  -> Red
# 
# Note: SSL Code for reading cert was adopted from:
#       https://iamoffthebus.wordpress.com/2014/02/04/powershell-to-get-remote-websites-ssl-certificate-expiration/
#
# Rules:  
#   1) Send out a "STATUS Email every 15 days - on the 1st and 15th day of the month
#   2) Send a reminder Email when cert expires in 30 days
#   3) Send a reminder Email when cert expires in 15 days
#   4) Send an alert Email every day when cert expires in 7 days or less and never stop
#
# Dependency: Powershell 5.0
# 
# How to run the script:
#   From the command line navigate to the root folder enter: 
#   Powershell.exe -file serverSSL.ps1 
#   Powershell.exe -file serverSSL.ps1 -help | -h | ?
#   Powershell.exe -file serverSSL.ps1 -debug
#   Powershell.exe -file serverSSL.ps1 -sbx | -noip 
#
# ************************************************************************************************

param (
    [switch]$debug,
    [switch]$noIp,
    [switch]$sbx,
    [switch]$help
)

# Show user valid args
if ($help -or $args -contains '?' -or $args -contains '-h') {
    Write-Host "Usage: .\YourScript.ps1 [options]" -ForegroundColor Cyan
    Write-Host "Options:" -ForegroundColor Cyan
    Write-Host "  -help, -h, ? : Display this help message" -ForegroundColor Cyan
    Write-Host " "
    Write-Host "  -debug : Enable debug mode" -ForegroundColor Cyan
    Write-Host "  -noip  : Do not perfrom an IP Lookup it will speed things up" -ForegroundColor Cyan
    Write-Host "  -sbx   : Test Mode - run in sanbox and prevent spamming user with emails" -ForegroundColor Cyan

    exit
}


# ******************************************************************************
# CertStatus object class definition 
# ******************************************************************************
class CertInfo {
    [String] $url 
    [String] $issuedOn 
    [String] $expiresOn 
    [int] $daysLeft 
    
    [String] $organization 
    [String] $contactInfo
    [String] $type 

    [String] $environment 
    [String] $description

    [String] $remoteIpAddress

    [bool] $isError
    [String] $eMessage
    [String] $eStackTrace
}

# ******************************************************************************
# Metrics object class definition - to track waht passed failed, etc
# ******************************************************************************
class Metrics {
    [int] $total = 0
    [int] $processed = 0
    [int] $errors = 0
    [int] $warnings = 0
    [int] $skipped = 0
}

# ******************************************************************************
# Function sendEmail
# ******************************************************************************
function sendEmail($mailInfo, $subject, $msgBody, $sendAlertTo) {

    #  Combine the default list with the list on contacts from the "sendAlertTo" and remove duplicates
    $sendAlertTo = $($mailInfo.to).split(";") +  $sendAlertTo
    $sendAlertTo = $sendAlertTo | Select-Object -uniq
    
    $sendCc = $($mailInfo.cc).split(";")

    # Ovveride if DEBUG or SBX to avoid spamming
    if($global:DEBUG -eq $true -or $config.sbx -eq $True) {
        $sendAlertTo = @("mcm8@cdc.gov")
        $sendCc = @("mcm8@cdc.gov")
        $subject = "SBX TEST - " + $subject
    }

    $mailParams = @{ 
        SmtpServer = $mailInfo.smptServer
        From = $mailInfo.from
        To = $sendAlertTo
        Cc = $sendCc
        BodyAsHtml = $true
        Subject = $subject
        Body = $msgBody
    }    
    
    Try {
        Send-MailMessage @mailParams -Priority High 
        Write-Host "| eMail Alert Sent [" $subject "]"-foregroundcolor $global:YELLOW
    }
    Catch {
        Write-Host "| " $Error -ForegroundColor $global:RED
    }
}

# ******************************************************************************
# Function setEmailBodyAsHtml
# ******************************************************************************
function getEmailBodyAsHtml($list, $config, $skipMetrics, $executionTime) {
    # Get base64 informatics log 
    $base64FilePath = Join-Path -Path $pwd -ChildPath $config.nchhstpLogo
    $base64Image = Get-Content -Path $base64FilePath -Raw
    
    # $base64Image = $base64Image -replace "`r`n", ""     

    # Setup HTML tableL from message to be sent 
    # Generate eMail body
    $tblHeader = ("<tr>" + 
                    "<th style='width:10px'><b>{0}</b></th>" +
                    "<th><b>{1}</b></th>" +
                    "<th><b>{2}</b></th>" + 
                    "<th><b>{3}</b></th>" + 
                    "<th><b>{4}</b></th>" +
                    "<th><b>{5}</b></th>" +
                    "<th><b>{6}</b></th>" +
                    "<th><b>{7}</b></th>" +
                    "<th><b>{8}</b></th>" +
                    "<th><b>{9}</b></th>" +
                    "<th><b>{10}</b></th>" + 
                "</tr>") -f "#", "Host Name", "Host IP", "Type", "Organization", "Contact", "Env.", "Description", "Issued On", "Expires On", "Days Left"

    $css = "<meta http-equiv='Content-Type' content='text/html; charset=us-ascii'></head>
        <style> 
            body {
                font-family: Arial;
                font-size: 14px;
            }
            .myTable {
                width: 100%;
                border: 1px solid #CCCCCC;
                border-collapse: collapse;
                padding: 5px;
            }

            .myTable th {
                border: 1px solid #CCCCCC;
                padding: 5px;
                background: #F0F0F0;
            }

            .myTable td {
                border: 1px solid #CCCCCC;
                padding: 5px;
            }

            .center {
                text-align: center;
            }            

            .left {
                text-align: left;
            }            


            .footer {
                width: 100%;
                background-color: #F5F5F5;
                border: 1px #CCCCCC;
            }        
        </style>"

    $footer = ("<table class='myTable'>
                    <tbody><tr><td>
                        <table class='footer'>
                            <tr>
                                <td style='border: none; color:#203864;'>
                                    <div>This email was generated by the <u>{0}</u></div>
                                    <div style='color: #D04437;'><b>Technology Services provided by the NCHHSTP Informatics Office</b></div>
                                    <div style='margin-top: 5px;'>
                                        <b>NCHHSTP Powershell Script: {1} - Version: {2} (Build: {3} sha1:{4})</b><br>
                                        <a href='https://github.com/cdcent/NCHHSTP-IO-Server-SSL' alt='Fork us on GitHub'>Fork us on GitHub</a>
                                    </div>
                                    <div style='font-size: 11px; font-weight: bold; color: #D04437; margin-top: 5px;'>
                                        Runner: {5} [{6}]
                                    </div>
                                </td>
                                
                                <td style='border: none; width: 1px; vertical-align: top;'>
                                    <img  alt='Informatics logo' src='data:image/png;base64,{7}'>

                                </td> 
                            </tr>
                        </table>
                    </td></tr></tbody>
                </table>") -f $config.description,  $global:commandName,  $config.version, $config.build, $global:shortCommitHash, $global:HOST_FQDN, $global:HOST_IP, $base64Image
    
    $metrics = ("<div style='color: blue; font-size: 18px;'>
                    <b>
                        Metrics: 
                        Total: {0}&nbsp;&nbsp; 
                        Processed: {1}&nbsp;&nbsp; 
                        Skipped: {2}&nbsp;&nbsp; 
                        Wanings: {3}&nbsp;&nbsp; 
                        Errors: {4}<br>
                        Execution Time: {5}
                    </b>
                </div>" +
                "<div style='color: #D04437; margin-top: 5px;'><b>NOTE: </b><u>Skipped</u> Items are not displayed in the above list. If required consult the logs for more information.</div>") -f $global:metrics.total, $global:metrics.processed, $global:metrics.skipped, $global:metrics.warnings, $global:metrics.errors, $executionTime

    $msgBody = New-Object System.Collections.ArrayList
    $msgBody.add( ("<html><head>{0}</head><body>") -f $css ) | Out-Null

    if($global:DEBUG -eq $true) {
        $msgBody.add("<font style='color: #D04437;'><b>THIS IS A TEST EMAIL PLEASE DISREGARD</b></font><br><br>The server(s) listed below have SSL certificates. Please review the list and if necessary schedule time to renew and install the certificates prior to the expiration date listed.<br><br>") | Out-Null
    }
    else {
        $msgBody.add("<div>The server(s) listed below have SSL certificates. Please review the list and if necessary schedule time to renew and install the certificates prior to the expiration date listed.</div>") | Out-Null
    }
    
    $msgBody.add("<div style='color: #D04437;'><b>Note: </b>This email has been sent from an unmonitored mailbox. DO NOT REPLY TO THIS EMAIL. Please direct all inquiries to the NCHHSTP Informatics helpdesk</div><br>") | Out-Null
    $msgBody.add("<table class='myTable'>") | Out-Null
    $msgBody.add($tblHeader) | Out-Null

    # Loop through the server list sorted by "daysLeft" and create a pretty output to be sent via email and add a line item counter
    $count = 0
    foreach ($i in ($list | Sort-Object daysLeft) ) {
        $count++
        if ($i.isError -eq $false) {
            $color = ""
            if ($i.daysLeft -gt 29) {      # Color Green
                $color = "#009432"
            }
            elseif ($i.daysLeft -gt 7) {   # Color Orange
                $color = "#F79F1F"
            }        
            else {                         # Color Red
                # $color = "#EA2027"
                $color = "#D04437;"
                
            }

            $s = ("<tr>" +
                    "<td style='text-align: center;'><font style='color: {0}; font-weight: normal'>{1}</font></td>" +
                    "<td><font style='color: {0}; font-weight: normal'>{2}</font></td>" +
                    "<td class='center'><font style='color: {0}; font-weight: normal'>{3}</font></td>" +
                    "<td class='center'><font style='color: {0}; font-weight: normal'>{4}</font></td>" +
                    "<td class='center'><font style='color: {0}; font-weight: normal'>{5}</font></td>" +
                    "<td class='center'><font style='color: {0}; font-weight: normal'>{6}</font></td>" +
                    "<td class='center'><font style='color: {0}; font-weight: normal'>{7}</font></td>" +
                    "<td class='left'><font style='color: {0}; font-weight: normal'>{8}</font></td>" +
                    "<td class='center' style='white-space: nowrap;'><font style='color: {0}; font-weight: normal'>{9}</font></td>" +
                    "<td class='center' style='white-space: nowrap;'><font style='color: {0}; font-weight: normal'>{10}</font></td>" +
                    "<td class='center'><font style='color: {0}; font-weight: bold'>{11}</font></td>" + 
                "</tr>") -f $color, $count, $i.url, $i.remoteIpAddress, $i.type, $i.organization, $i.contactInfo.Replace(";", "; "), $i.environment, $i.description, $i.issuedOn, $i.expiresOn,  $i.daysLeft

            $msgBody.add($s) | Out-Null
        }
        else {
            $s = ("<tr>" + 
                    "<td style='color: #EA2027; text-align: center;'>{0}</td>" + 
                    "<td colspan='10'>" + 
                        "<div style='color: #EA2027; font-weight: bold'>{1} [IP: {2}]</div>" +
                        "<div style='color: #EA2027; font-family: courier;'>  <b>(Unable to access SSL Certificate information)</b><br><b>[ERROR]</b> {2} <br><b>[STACKTRACE]</b> {3}</div>" + 
                    "</td>" + 
                "</tr>") -f $count, $i.url, $i.remoteIpAddress, $i.eMessage, $i.eStackTrace

            $msgBody.add($s) | Out-Null
        }
    }

    if ($skipMetrics -eq $false) {
        $s = ("<tr style='background-color: #F5F5F5;'><td colspan='11'>{0}</td></tr>") -f $metrics
        $msgBody.add($s) | Out-Null
    }

    $msgBody.add("</table>") | Out-Null
    $msgBody.add("<br>") | Out-Null
    $msgBody.add("<br>") | Out-Null
    $msgBody.add($footer) | Out-Null
    $msgBody.add("</body></html>") | Out-Null
    
    return $msgBody
}

# ******************************************************************************
# Function get source of url (host and port) 
# ******************************************************************************
function getIp($url) {
    Write-Host -NoNewline ("IP: ")

    if ($global:EXCLUDE_IP_LOOKUP -eq $false) {
        $url =  [Uri] $server.url
        $Global:ProgressPreference = 'SilentlyContinue'
        
        $r = Test-NetConnection -ComputerName $url.host -Port $url.port -WarningAction SilentlyContinue | Select RemoteAddress, SourceAddress, PingSucceeded 
        $ip = ([String] $r.RemoteAddress).PadRight(15)
        Write-Host -NoNewline ("$ip | ")
        return ([String] $r.RemoteAddress).PadRight(15)
    }
    else {
        Write-Host -NoNewline ("Excluded | ")
        return ([String] "Excluded").PadRight(15)
    }
}


# ******************************************************************************
# Function checkSslCertificate 
# Loop through the host list and try to get the SSL cert expiration date
# and calculates the days left.
# 
# Return List and execution time
# 
# NOTE: if skipTest = true then the SSL test will be skipped
# ******************************************************************************
function checkSslCertificate($config) {
    # Start a stop watch instance
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

    $list = New-Object System.Collections.ArrayList

    # TLS and certificate validation setup only support TLS 1.2
    [Net.ServicePointManager]::SecurityProtocol =  [Net.SecurityProtocolType]::Tls12
    [Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

    foreach ($server in $config.servers) {
        Write-Host -NoNewline ("One Moment - URL: " + $server.url + " | ")
        
        $global:metrics.total++

        $myColor = $global:GREEN
        $req = [Net.HttpWebRequest]::Create($server.url) 
        $req.Timeout = $global:timeoutMilliseconds 
        $env = ($server.environment).PadRight(4)
        $url = ($server.url).PadRight(60)
        $ip = getIp($server.url)

        if ($server.skipTest) {
            Write-Host "`rEnv: " $env "| IP: " $ip  "URL: " $url  ("| Status: [SKIPPED] ")  -foregroundcolor $global:GRAY
            $global:metrics.skipped++
            continue
        }
    
        try {
            Write-Host -NoNewline ("Response: ")
            $req.GetResponse() | Out-Null
            Write-Host -NoNewline ("OK")
            Write-Host -NoNewline "`rEnv: " $env "| IP: " $ip  "URL: " $url  ("| Status: [OK] ").PadRight(20)  -foregroundcolor $myColor
            $global:metrics.processed++
        } 
        catch {
            $myColor = $global:RED
            $myStatus = "ERROR"
            if($null -ne $req.ServicePoint.Certificate) {
                $myColor = $global:YELLOW
                $myStatus = "WARN"
                $global:metrics.warnings++
            }
            else {
                $global:metrics.errors++
            }
            Write-Host -NoNewline ("$myStatus")
            Write-Host -NoNewline "`rEnv: " $env "| IP: " $ip  "URL: " $url ("| Status: [" + $myStatus + "] ").PadRight(20) -foregroundcolor $myColor
        }
        
        # The cert was accessible event if we might have recived an exception
        if($null -ne $req.ServicePoint.Certificate) {
            $cert = $req.ServicePoint.Certificate
    
            # Let's do some math and calculate how many days are left on the certificate If any item is less or equal to 30 days 
            [datetime]$effective = $cert.GetEffectiveDateString()
            [datetime]$expiration = $cert.GetExpirationDateString()

            [String]$daysLeft = (($expiration - $((get-date).date)).Days).ToString()

            if($null -eq $Error[0].Exception.Message) {
                Write-Host "Expiring in: " $daysLeft.PadLeft(6) -foregroundcolor $myColor
            }
            else {
                Write-Host "Expiring in: " $daysLeft.PadLeft(6) " " $Error[0].Exception.Message -foregroundcolor $myColor
            }

            # If any item is less or equal to 30 days then the automatically set the flag to send out an email
            if ($daysLeft -le 30) {
                $global:sendEmailAlert = $true
            }

            # Load server information into the class and add to an array list 
            $obj = New-Object CertInfo
            $obj.url = $server.url
            $obj.IssuedOn = $effective.ToString("MM/dd/yyyy HH:mm:ss")
            $obj.expiresOn = $expiration.ToString("MM/dd/yyyy HH:mm:ss")
            $obj.daysLeft = $daysLeft
            $obj.organization = $server.organization
            $obj.contactInfo = $server.contactInfo
            $obj.type = $server.type
            $obj.environment = $server.environment
            $obj.description = $server.description
            $obj.remoteIpAddress = $ip
            $obj.isError = $false

            $list.add($obj) | Out-Null
        }
        else {
            # Something went wrong get exception and report it back
            # This was a complete failure and the utility is un able to reach the resource and query the cert it could ab bad URL and FW issue etc.
            # Load server information into the class and add to an array list 
            $obj = New-Object CertInfo
            $obj.url = $server.url
            $obj.isError = $true
            $obj.daysLeft = 99999
            $obj.organization = $server.organization
            $obj.contactInfo = $server.contactInfo
            $obj.type = $server.type
            $obj.environment = $server.environment
            $obj.description = $server.description        
            $obj.remoteIpAddress = $ip    
            $obj.eMessage = $Error[0].Exception.Message
            $obj.eStackTrace = $Error[0].Exception.StackTrace
    
            $len = ($obj.eMessage).Length
            Write-Host $obj.eMessage.padLeft($len + 23) -foregroundcolor $myColor

            $list.add($obj) | Out-Null
        }
    
    }
    
    # Calcluate execution time 
    $stopwatch.Stop()
    $executionTime = [string]::Format("{0:hh\:mm\:ss}", $stopwatch.Elapsed)

    Write-Host " "    
    Write-Host "+-----------------------------------------------------------------------------+" -foregroundcolor $global:YELLOW    
    Write-Host "| Metrics: " -foregroundcolor $global:YELLOW 
    Write-Host "|  " -foregroundcolor $global:YELLOW -NoNewline; Write-Host "Total:    " $global:metrics.total  -foregroundcolor $global:YELLOW
    Write-Host "|  " -foregroundcolor $global:YELLOW -NoNewline; Write-Host "Procesed: " $global:metrics.processed -foregroundcolor $global:GREEN 
    Write-Host "|  " -foregroundcolor $global:YELLOW -NoNewline; Write-Host "Skipped:  " $global:metrics.skipped -foregroundcolor $global:GRAY 
    Write-Host "|  " -foregroundcolor $global:YELLOW -NoNewline; Write-Host "Warnings: " $global:metrics.warnings  -foregroundcolor $global:YELLOW 
    Write-Host "|  " -foregroundcolor $global:YELLOW -NoNewline; Write-Host "Errors:   " $global:metrics.errors  -foregroundcolor $global:RED 
    Write-Host "+-----------------------------------------------------------------------------+" -foregroundcolor $global:YELLOW    
    Write-Host "| Execution time: $executionTime" -foregroundcolor $global:YELLOW 
    Write-Host "+-----------------------------------------------------------------------------+" -foregroundcolor $global:YELLOW 

    # ******************************************************************************
    # NOTE: Only run this code when testing with edge test cases to verify thresholds
    # ******************************************************************************
    if($global:DEBUG -eq $true) {
        addTestCase $list 0
        addTestCase $list 1
        addTestCase $list -1
        addTestCase $list 31
        addTestCase $list 30
        addTestCase $list 30
        addTestCase $list 30
        addTestCase $list 29
        addTestCase $list 16
        addTestCase $list 15
        addTestCase $list 15
        addTestCase $list 15
        addTestCase $list 14

        addTestCase $list 7
        addTestCase $list 8
        addTestCase $list 6
        addTestCase $list 5

        addTestCase $list 365
        addTestCase $list 60
        addTestCase $list -365
        addTestCase $list 99999 $true
        addTestCase $list 99999 $true
    }
        return @($list, $executionTime)
}

# ******************************************************************************
# Function addTestCase Used in simulating data for testing 
# ******************************************************************************
function addTestCase($list, $daysLeft, $error) {
    $url =  -join ((65..90) + (97..122) | Get-Random -Count 15 | ForEach-Object {
            [char]$_}
        )

    $obj = New-Object CertInfo
    
    $obj.url = "https://TEST-CASE[" +  $daysLeft + "]" + $url + ".COM/9443"
    $obj.IssuedOn = Get-Date
    $obj.expiresOn =  (Get-Date).AddDays($daysLeft)
    $obj.organization = "NCHHSTP"
    $obj.type = "Server"
    $obj.contactInfo = "myEmail@gmail.com"

    $obj.daysLeft = $daysLeft
    $obj.isError = $false

    if ($error -eq $true) {
        $obj.isError = $true
        $obj.eMessage = "ConsoleApplication1.MyCustomException: some message .... ---> System.Exception: EXCEPTION SIMULATION!"
        $obj.eStackTrace = "   at ConsoleApplication1.SomeObject.OtherMethod() in C:\ConsoleApplication1\SomeObject.cs:line 24
        at ConsoleApplication1.SomeObject..ctor() in C:\ConsoleApplication1\SomeObject.cs:line 14
        --- End of inner exception stack trace ---
        at ConsoleApplication1.SomeObject..ctor() in C:\ConsoleApplication1\SomeObject.cs:line 18
        at ConsoleApplication1.Program.DoSomething() in C:\ConsoleApplication1\Program.cs:line 23
        at ConsoleApplication1.Program.Main(String[] args) in C:\ConsoleApplication1\Program.cs:line 13"
    }

    if ($daysLeft -lt 30) {
        $global:sendEmailAlert = $true
    }

    $list.add( $obj ) | Out-Null
}

# ******************************************************************************
# Function show console banner 
# ******************************************************************************
function showConsoleBanner() {
    Write-Host "     " -foregroundcolor $global:YELLOW
    Write-Host "      _____ _____ __                                                           " -foregroundcolor $global:YELLOW 
    Write-Host "+----/ ___// ___// /----------------------------------------------------------+" -foregroundcolor $global:YELLOW 
    Write-Host "|    \__ \ \__ \/ /    ..........    >X<   .....   @__   .....   _/7   .....  |" -foregroundcolor $global:YELLOW 
    Write-Host "|   ___/ /___/ / /___  ..........   (o o)  .....  (o o)  .....  (o o)  .....  |" -foregroundcolor $global:YELLOW 
    Write-Host "+--/____/\____/_____/-----------ooO--(_)--Ooo-ooO--(_)--Ooo-ooO--(_)--Ooo-----+" -foregroundcolor $global:YELLOW 
    Write-Host "|                                                                             |" -foregroundcolor $global:YELLOW 
    Write-Host "|  Center for Disease Control and Prevention (CDC)                            |" -foregroundcolor $global:YELLOW 
    Write-Host "|  National Center for HIV, Viral Hepatitis, STD, and TB Prevention (NCHHSTP) |" -foregroundcolor $global:YELLOW 
    Write-Host "|  CDC/NCHHSTP/OD/Informatics Office (IO)                                     |" -foregroundcolor $global:YELLOW 
    Write-Host "+-----------------------------------------------------------------------------+" -foregroundcolor $global:YELLOW 
    Write-Host "| ", $config.description -foregroundcolor $global:YELLOW

    Write-Host "|  Version: " -foregroundcolor $global:YELLOW -NoNewline
    Write-Host $config.version -foregroundcolor $global:GREEN -NoNewline
    Write-Host " Build: " -foregroundcolor $global:YELLOW -NoNewline
    Write-Host $config.build -foregroundcolor $global:GREEN -NoNewline
    Write-Host " sha1:" -foregroundcolor $global:YELLOW -NoNewline
    Write-Host $global:shortCommitHash -foregroundcolor $global:GREEN

    Write-Host "+-----------------------------------------------------------------------------+" -foregroundcolor $global:YELLOW 
    Write-Host "| FQDN Runner:         " $global:HOST_FQDN [$global:HOST_IP] -foregroundcolor $global:YELLOW     
    Write-Host "| Command:             " $global:commandName -foregroundcolor $global:YELLOW 
    Write-Host "|  Parameters:         " $global:params -foregroundcolor $global:YELLOW 

    Write-Host "| " 
    Write-Host "| Configuration:       " $global:configName -foregroundcolor $global:YELLOW 
    Write-Host "|  sendEmailAlert:     " $global:sendEmailAlert -foregroundcolor $global:YELLOW 
    Write-Host "|  timeoutMilliseconds:" $global:timeoutMilliseconds -foregroundcolor $global:YELLOW   
    Write-Host "|  SBX:                " $config.sbx -foregroundcolor $global:YELLOW 

    Write-Host "|  DEBUG:              " $global:DEBUG -foregroundcolor $global:YELLOW 
    Write-Host "|  EXCLUDE_IP_LOOKUP:  " $global:EXCLUDE_IP_LOOKUP -foregroundcolor $global:YELLOW 
    Write-Host "+-----------------------------------------------------------------------------+" -foregroundcolor $global:YELLOW 
    Write-Host "| Mail Configuration:  "  -foregroundcolor $global:YELLOW     
    Write-Host "|  SMTP Gateway:       " $config.mailInfo.smptServer -foregroundcolor $global:YELLOW 
    Write-Host "|  FROM:               " $config.mailInfo.from -foregroundcolor $global:YELLOW 
    Write-Host "|  TO:                 " $config.mailInfo.to -foregroundcolor $global:YELLOW 
    Write-Host "|  CC:                 " $config.mailInfo.cc -foregroundcolor $global:YELLOW 
    Write-Host "+-----------------------------------------------------------------------------+" -foregroundcolor $global:YELLOW 
    Write-Host "     " -foregroundcolor $global:YELLOW     
}

# ******************************************************************************
#  __  __     _     ___   _  _
# |  \/  |   /_\   |_ _| | \| |
# | |\/| |  / _ \   | |  | .` |
# |_|  |_| /_/ \_\ |___| |_|\_|
# ******************************************************************************
# Program Entry point 
# From CLI: 
#   Powershell.exe -file serverSSL.ps1 
# Parameters: 
#   -help, -h, ?: For help
#   -debug      : Turn on debug default false
#   -noip       : Do not perfrom IP Lookup default is perfrom ip Lookup
#   -sbx        : Run in sand box mode ovly for testing and code modifications when runninf script
# 
# NOTE: Function declarations are defined above the entry point 
# ******************************************************************************

$global:params = ($PSBoundParameters.GetEnumerator() | ForEach-Object { "-$($_.Key)=$($_.Value)" }) -join " "

$global:shortCommitHash = (git rev-parse HEAD).Substring(0, 8)
$global:commandName = $MyInvocation.MyCommand.Name
$global:HOST_FQDN = [System.Net.Dns]::GetHostByName($env:ComputerName).HostName
$global:HOST_IP = (Test-Connection -ComputerName ($global:HOST_FQDN) -Count 1).IPV4Address.IPAddressToString

$global:GREEN = "green"
$global:RED = "red"
$global:YELLOW = "yellow"
$global:GRAY = "gray"

$global:metrics = New-Object Metrics            # Used in trackinng ssl process and display results
$global:configName = "sslConfig.json"
$global:sendEmailAlert = $true
$global:timeoutMilliseconds = 10000

$config  = (Get-Content -Path ($PSScriptRoot+"\"+$global:configName) -Raw) | ConvertFrom-Json    

# Processs name parameters
if (-not $debug) {
     $global:DEBUG = $false                     # In console and emails
}

$global:EXCLUDE_IP_LOOKUP = $false  
if ($noip) {
    $global:EXCLUDE_IP_LOOKUP = $true           # Set to true to speed up things 
}

if ($sbx) {
    $config.sbx = $true                         # Sandbox tesing override
}

showConsoleBanner

Write-Host ("Start: [{0}]" -f (Get-Date).ToString("MM/dd/yyyy HH:mm:ss")) -ForegroundColor $global:GREEN
Write-Host " "

# fucntion returns two objects statusList and executionTime
$result = checkSslCertificate $config
$statusList = $result[0]
$executionTime = $result[1]

$showNoEmailSentMessage = $true
if ($global:sendEmailAlert -eq $true) {
    # Filter list with only items that have days left = 30
    $filteredList = @($statusList | Where-Object { $_.daysLeft -eq 30 })
    if ($filteredList.Count -gt 0) {
        $showNoEmailSentMessage = False
        $msg = getEmailBodyAsHtml $filteredList $config $true $executionTime
        sendEmail $config.mailInfo  $("SSL 30 DAY REMINDER: " + $config.mailInfo.subject)  $($msg -join "`n" ).Replace("`n", "")  $filteredList.contactInfo  | Out-Null
    }

    # Filter list with only items that have days left = 15
    $filteredList = @($statusList | Where-Object { $_.daysLeft -eq 15 })
    if ($filteredList.Count -gt 0) {
        $showNoEmailSentMessage = $false
        $msg = getEmailBodyAsHtml $filteredList $config $true $executionTime
        sendEmail $config.mailInfo  $("SSL 15 DAY REMINDER: " + $config.mailInfo.subject)  $($msg -join "`n" ).Replace("`n", "")  $filteredList.contactInfo  | Out-Null
    }

    # Filter list with only items that have days left = 7 or less
    $filteredList = @($statusList | Where-Object { $_.daysLeft -le 7 })
    if ($filteredList.Count -gt 0) {
        $showNoEmailSentMessage = $false
        $msg = getEmailBodyAsHtml $filteredList $config $true $executionTime
        sendEmail $config.mailInfo  $("SSL DAILY CRITICAL ALERT: " + $config.mailInfo.subject)  $($msg -join "`n" ).Replace("`n", "")  $filteredList.contactInfo  | Out-Null
    }
}

# Always Send a status email every 1st and 15th day of the month regardless  
if ( (Get-Date).Day -eq 1 -Or (Get-Date).Day -eq 15) {
    $showNoEmailSentMessage = $false
    $msg = getEmailBodyAsHtml $statusList $config $false $executionTime
    sendEmail $config.mailInfo  $("SSL STATUS: " + $config.mailInfo.subject)  $($msg -join "`n" ).Replace("`n", "") | Out-Null
}

if ($config.sbx -eq $true) {
    $showNoEmailSentMessage = $false
    $msg = getEmailBodyAsHtml $statusList $config $false $executionTime
    sendEmail $config.mailInfo  $("SSL STATUS: " + $config.mailInfo.subject)  $($msg -join "`n" ).Replace("`n", "") | Out-Null
}

if ($showNoEmailSentMessage -eq $true) {
    Write-Host "| No eMmail allerts Sent" -foregroundcolor $global:YELLOW     
}

Write-Host "+-----------------------------------------------------------------------------+" -foregroundcolor $global:YELLOW 
Write-Host " "
Write-Host ("End: [{0}]" -f (Get-Date).ToString("MM/dd/yyyy HH:mm:ss")) -ForegroundColor $global:GREEN

